def int_identity(a: int) -> int:
    return a

def main():
    print(int_identity(5))

def what_even(a: int, b: str, c = 5) -> str:
    def heh(a):
        pass
    pass

PY-TYPES (PYPES?!)
-------------

Gradual typing for Python 3. Python 2 won't be supported due to lack of annotations in functions.


How to use
-----------

At the moment, only runtime schemas and type-checking is supported.  These definitely have a performance overhead:
 I haven't profiled anything to check how much of an overhead there is though.

####schemas

Schema checking is meant to enforce structure and type in list and dictionary arguments.

To use schema checking, declare a structure with the types you want to see reflected in the input you get,
and then wrap the function you want to check with `@schema`, and the schema you want for a particular argumnet as the annotation.

schema assert examples (with built-in types):

```python
 test_schema = {
     "hello": int,
     "world": {
         "people": [str],
         "version": int
     },
     "optional": (int, type(None))
 }

 @schema
 def schema_checked(a: test_schema) -> test_schema:
     b = deepcopy(a)
     b["hello"] += 5
     if b["world"]["people"]:
         b["world"]["people"][0] = "Bob"
     b["world"]["version"] += 1
   return b
```

```python
from functools import reduce

list_schema = [int]

@schema
def sum(li: list_schema) -> int:
    def add(a, b):
        return a + b

    return reduce(add, li)
```

Note that custom types as well as built-ins can be used.  (See "Sane, friendlier types" for more on custom ones.)


Homogenous, heterogenous lists - Note that when using a list as a schema, the schema decorator differentiates between two types of lists.
If your schema's list value has one element, it's homogenous, and schema will assume that any length is acceptable, as long as every element
matches the schema of the one element that the list has.  If there are multiple elements, it is heterogenous.  Schema assumes that the length
of heterogenous lists must match the number of elements specified, and that each item in the list will match the schemas in the list in order.
(I.e., they are order-dependent.)  
If some of this behaviour seems undesirable, custom or validated types can be used to combat some of it, but there is no other solid solution.

####typechecking

Type checking is meant to flat-out test values via isinstance.  Schemas use the same thing internally,
and type checking can be mixed and matched with schemas in the same function signature. (No tests for this yet!  But will be added soon.)

Because the arguments are passed straight through to isinstance, a tuple of types can be given, and it will return true
if the argument is any one of the given types.

some typechecking examples:
```python
# this will run normally unless best or slot are incorrect types
@typecheck
def type_checked(best: int, slot: str) -> str:
    return slot * best

# this will always throw an exception due to return type
@typecheck
def bad_return(a: int) -> int:
    return str(a)

```

This is meant to be used with custom types/classes, and is mostly just a stepping stone for better applications of type checking.


Sane, friendlier types
----------------

Since python's built-ins weren't really meant for type checking or static analysis, I'm working on
building out new types inspired by Haskell/Rust but suitable for python.

There are some working definitions and code in type_defs, but they need some serious work and don't cover
anywhere near what they should.

#### base, inheritable type classes

They do provide extensible "types" via the `type_defs.base.TypeFamily` metaclass, and provide some interesting
data types such as `type_defs.structured_types.TypedSequence`.  
If you do extend types using TypeFamily, the class will automatically return true for isinstance calls when compared
with any member of `my_class.type_members` (declared at top level).  If you need custom behaviour that works with
the type and schema checks, make sure that any custom logic is in the class's `__instancecheck__`.

`type_defs.base.ValidatedType` has been added, which essentially inherits a list of validator functions and type
values.  Its `__instancecheck__` is customized to run the validators on the given value.


#### function types

Added a custom Function type in `type_defs.functions`.  This type allows you to specify and check for callables with
specific arity (number of arguments) and return types. Added because checking against Callable was not a very good guarantee!

Note that these types purposefully do not check for a schema return type or handle inoperability there.  The Function type will
only compare the direct return type of the function given.  
If you'd like a particular function's return value to be schema checked at runtime, just define the function with the @schema
decorator.


#### notes on use of isinstance

Note that in any type-checking, "union" types can be given with a tuple, which will match
any of the types (because the type checking is done via isinstance).  So, the following code will typecheck successfully
with either an int or None instance.

```python
@typecheck
def retry_if_failed(code: (int, type(None))) -> type(None):
    # must handle None or int
    pass
```

Because everything is done through isinstance, the custom types should compose and work normally with other types, classes, etc.

Please note that some cases of using this with the schema decorator may not work as intended -- if you want to accept multiple
types or schemas with the schema decorator, please use the the `runtime.schema.SchemaOr` class with the types/schemas as args.


Future enhancements
----------------

Next up on the to-do list for this project:
- full test coverage! Currently missing schema tests and Function tests.
- add an installation package to pypi.
- Move some of this README to documentation instead.
- static type checking! A tool to run and check what it can statically, and leave in run-time checks for what it can't.

CHANGELOG
--------------------------------------
# Change log

Trying to follow [semantic versioning](http://semver.org) as much as possible.

## [Unreleased][unreleased]

### Added

- Added error messaging for schema. It will now give the function and argument name, path to the part of the schema it was looking at
    (e.g. 'data[0]["key1"]'), and the expected and actual type.

### Changed

- Improved error messaging for typecheck; it now specifies what the expected and actual values were.
- Changed the directory structure for easier importing.  The previous release forced the user to use the path `py_types.py_types`.
- Fixed a bug that did not allow typecheck and schema decorators to be used together on the same function.
  - I thought this was tested before, but it appears it wasn't.

- `type_defs.composition` has been removed. [DEPRECATED]
- `runtime.asserts`'s validation functions have been removed (validate, ValidationResult, ValidationError). [DEPRECATED]
    I felt this was an inferior version of functionality already given through `type_defs.base.ValidatedType`.
    If you wish to use functions you'd want to run through validate, please use a ValidatedType with `runtime.asserts.typecheck` instead.


## 0.0.1a - 2015-07-10
Any items with the [UNUSED] tag are not normally run as part of the intended api, and are probably undocumented.

### Added
- A type definitions module, containing code with new sane types and structure for them
  - Base type classes TypeFamily and ValidatedType (`type_defs.base`).
    - These inherit attributes and use the inherited attributes in their `__instancecheck__`
  - a custom Function type to check against arity and return type in type_defs.functions. [UNTESTED]
  - Some common types that might be applicable children of TypeFamily in `type_defs.common`.
  - Typed sequence and dictionary types in `type_defs.structured_types`.
  - Some old composition operators in `type_defs.composition`. DO NOT USE. [UNUSED]
    - These will be removed in the next version.

- A runtime module containing code for ensuring correctness during a program's runtime, which includes:
  - A typecheck decorator, which asserts that arguments matched their annotated type via isinstance().
  - A validator decorator, which asserts that functions declared as annotations return true for their arguments.
  - A schema decorator, which asserts that the argument matches the detailed structure of the annotation.

- Tests module, with basic tests for all runtime code and most type-def code.

- ideal.py, a short file describing syntax possibilities for full type checking [UNUSED]
- a utils module with some unused functional operations [UNUSED]
- a static module, which contains early, experimental and untested static parsing code. [UNUSED]

### Changed
- Heavily expanded README.md to include documentation and direction.


[unreleased]: https://github.com/zekna/py-types/compare/v0.0.1a...HEAD


